
import random

def validate_idea(idea):
    score = random.randint(6, 10)
    return score
